create
    definer = root@localhost procedure getCountryCount(OUT countryCount int)
BEGIN
    SELECT COUNT(*) INTO countryCount FROM country;
END;

